--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.15 (Ubuntu 10.15-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 12.8 (Ubuntu 12.8-0ubuntu0.20.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ib;
--
-- Name: ib; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ib WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


ALTER DATABASE ib OWNER TO postgres;

\connect ib

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: op_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.op_type AS ENUM (
    'debit',
    'credit'
);


ALTER TYPE public.op_type OWNER TO postgres;

SET default_tablespace = '';

--
-- Name: balances; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.balances (
    id bigint NOT NULL,
    balance numeric(15,2)
);


ALTER TABLE public.balances OWNER TO postgres;

--
-- Name: operation_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.operation_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.operation_sequence OWNER TO postgres;

--
-- Name: operations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.operations (
    id bigint NOT NULL,
    date date NOT NULL,
    current_balance_id bigint NOT NULL,
    type public.op_type,
    correspond_balance_id bigint NOT NULL,
    sum numeric(15,2) NOT NULL
);


ALTER TABLE public.operations OWNER TO postgres;

--
-- Data for Name: balances; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.balances (id, balance) FROM stdin;
\.
COPY public.balances (id, balance) FROM '$$PATH$$/2922.dat';

--
-- Data for Name: operations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.operations (id, date, current_balance_id, type, correspond_balance_id, sum) FROM stdin;
\.
COPY public.operations (id, date, current_balance_id, type, correspond_balance_id, sum) FROM '$$PATH$$/2923.dat';

--
-- Name: operation_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.operation_sequence', 16, true);


--
-- Name: balances balances_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.balances
    ADD CONSTRAINT balances_pkey PRIMARY KEY (id);


--
-- Name: operations operations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_pkey PRIMARY KEY (id);


--
-- Name: operations operations_correspond_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_correspond_balance_id_fkey FOREIGN KEY (correspond_balance_id) REFERENCES public.balances(id);


--
-- Name: operations operations_current_balance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.operations
    ADD CONSTRAINT operations_current_balance_id_fkey FOREIGN KEY (current_balance_id) REFERENCES public.balances(id);


--
-- PostgreSQL database dump complete
--

